P101 Unit 11 v1.0 — 30 October 2026
Open unit11.html in a modern browser. All teaching mathematics and images are embedded. Hints and solutions are closed until requested. Navigation connects local reading and downloads. External references require internet access.
Run the notebook or Python companion with Python3 and Matplotlib. The starter runs without completing learner cells; those cells and explanations are your activity work.
Original teaching/diagrams CC BY-NC-SA4.0; Python MIT. Generator photo: Science Museum Group / Board of Trustees, CC BY-NC-SA4.0. Magnet photo: MikeRun and Vera Wurmsdobler, CC BY-SA4.0. Source links and full credits in captions. Branding excluded.
