P101 Unit 8 — Oscillation and sampled signals
LibraUni · Version 1.0 · 24 October 2026
Start with unit8.html, then unit8-lesson1.html through unit8-lesson5.html.
Block3.html provides the wider introduction. The reference is available as HTML and PDF.
Extract the ZIP before opening files. Reading, native mathematics, figures and disclosures work offline in a modern browser. The sampling exploration uses local JavaScript and has an equivalent static comparison; clipboard copying may require manual selection in local-file mode.
Notebook/script: Python3 with NumPy and Matplotlib, using the existing P101 setup. Public notebook is an unexecuted starter; complete Activities8.14/8.15 in your own cells. Generated values are synthetic, not measured evidence. No installation or account change is performed by this pack.
18h total including3hPython. Unit exercises and worked feedback are in Lesson5; solutions open only when requested. External further-reading links require internet access.
Original teaching/diagrams: CC BY-NC-SA4.0 (https://creativecommons.org/licenses/by-nc-sa/4.0/).
Code: MIT; licence below. LibraUni branding excluded.
Photographs retain separate terms: see MEDIA.json and each figure caption. No OU materials included.

MIT License — Copyright (c) 2026 LibraUni
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
