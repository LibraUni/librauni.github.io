P101 Unit 7 · Thermal transfers and testing a motion model
Open P101-Unit-7.html. Images and mathematics are embedded. Unit links and downloads work locally. External references and adjoining units need an internet connection. The checkpoint and capacity explorer run locally; neither saves or submits records.
Run Python 3 notebooks from this folder. Comparison plotting requires matplotlib; the CSV is included. Starters contain learner tasks; feedback is in the lessons.
Original teaching CC BY-NC-SA 4.0; original code MIT; NASA images retain NASA educational/editorial reuse terms and captions. R source/data/derived plots GNU GPLv2: see COPYING-R.txt and metadata. LibraUni branding excluded.
